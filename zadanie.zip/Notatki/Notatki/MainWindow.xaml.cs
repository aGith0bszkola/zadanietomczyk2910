﻿using System.Collections.ObjectModel;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Notatki
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<Notatka> listanotatek
            = new ObservableCollection<Notatka>();
        public MainWindow()
        {
            InitializeComponent();
            listanotatek.Add(new Notatka("Zakupy"));
            listanotatek.Add(new Notatka("Tenis","gra z ewa",true,DateTime.Today));
            listview.ItemsSource = listanotatek;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string tresc = trescbox.Text;
            string tytul = tytulbox.Text;
            bool wazna = (czydostepne.IsChecked == true);
            if (wazna) {
                listanotatek.Add(new Notatka(tytul, tresc, true, DateTime.Today));

            }
            else
            {
                listanotatek.Add(new Notatka(tytul, tresc, false, DateTime.Today));
            }
        }
    }
}
﻿using System;

namespace Notatki
{
    internal class Notatka
    {
        public Notatka(string tytul, string tresc,bool czyDostepna,DateTime dataDodania)
        {
            Tytul = tytul;
            Tresc = tresc;
            this.czyDostepna = czyDostepna;
            DataDodania = dataDodania;
        }

        public Notatka(string tytul)
        {
            Tytul = tytul;
            Tresc = "";
            czyDostepna = false;
            DataDodania = DateTime.Today;
        }

        public string Tytul { get; set; }

        public string Tresc { get; set; }

        public bool czyDostepna { get; set; }

        public DateTime DataDodania { get; set; }
    }
}